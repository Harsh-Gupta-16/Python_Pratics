"a {} {".format(1) # [bad-format-string]
