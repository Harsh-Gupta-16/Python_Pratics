# pylint: disable=blacklisted-name,no-value-for-parameter,missing-docstring

import subprocess


subprocess.run() # [subprocess-run-check]
