# coding: latin_1
#pylint: disable=invalid-name,missing-docstring

TOTO = ('Caf�', 'Caf�', 'Caf�')
