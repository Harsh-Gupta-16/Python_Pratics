#pylint: disable=missing-docstring

TEST_TUPLE = ('a', 'b'  # [implicit-str-concat]
              'c')
