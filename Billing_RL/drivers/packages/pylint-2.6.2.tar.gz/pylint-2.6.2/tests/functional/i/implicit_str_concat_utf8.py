#pylint: disable=invalid-name,missing-docstring

TOTO = ('Café', 'Café', 'Café')
