# pylint: disable=missing-module-docstring, too-few-public-methods


class Documented:
    "Something."
