Anything = 42
