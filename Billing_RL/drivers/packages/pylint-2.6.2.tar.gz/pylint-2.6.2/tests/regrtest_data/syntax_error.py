class A extends B {}
