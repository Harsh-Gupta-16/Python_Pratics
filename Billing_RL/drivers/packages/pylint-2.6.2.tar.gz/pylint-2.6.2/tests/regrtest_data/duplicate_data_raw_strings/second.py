r"""A raw docstring.
"""


def look_busy():
    xxxx = 1
    yyyy = 2
    zzzz = 3
    wwww = 4
    vvvv = xxxx + yyyy + zzzz + wwww
    return vvvv
