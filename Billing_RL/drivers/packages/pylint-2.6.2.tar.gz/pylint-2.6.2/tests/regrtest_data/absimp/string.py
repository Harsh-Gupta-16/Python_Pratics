"""
https://www.logilab.org/ticket/70495
https://www.logilab.org/ticket/70565
"""
from __future__ import absolute_import, print_function
import string
print(string)
