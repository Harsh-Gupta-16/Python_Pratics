ABC = something_undefined
